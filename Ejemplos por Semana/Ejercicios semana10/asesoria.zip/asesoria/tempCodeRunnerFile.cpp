 while (cad != "fin"){
        cout << "Ingresa una cadena (Escribe 'fin' para salir): " <<endl;
        getline(cin, cad);
        cout << cad;
    }