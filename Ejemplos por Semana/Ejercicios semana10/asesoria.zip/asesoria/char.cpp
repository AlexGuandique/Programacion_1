#include<iostream>
using namespace std;

int main()
{
    cout << "José";
    for(int i = 0; i <= 255; i++)
    {
        unsigned char x = i;
        cout << i <<") " << x <<endl;
    }
}