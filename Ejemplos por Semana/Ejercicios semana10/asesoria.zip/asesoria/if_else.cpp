#include<iostream>
using namespace std;

int main()
{
    int n = 10;

    if(n % 2 != 0){
        cout << n<<endl;
    }
    else if(n == 11){
        cout << n<<endl;
    }
    else if(n % 2 != 0){
        cout << n<<endl;
    }
    else{
        cout <<"Nada se cumplio"<<endl;
    }
    cout<<"\nFIN DEL PROGRAMA";
}